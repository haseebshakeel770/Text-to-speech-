package com.protts.app.engine

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume

data class LangOption(val code: String, val name: String, val nativeName: String)
data class VoiceOption(val id: String, val voice: Voice, val label: String, val offline: Boolean)

/**
 * Wraps Android's system TextToSpeech. The actual speech engine is whatever is installed on the
 * phone (Google TTS, eSpeak NG, RHVoice, Samsung TTS...). Only languages/voices the installed engine
 * really reports are exposed - nothing is invented.
 */
class TtsEngine(private val context: Context) {
    private var tts: TextToSpeech? = null
    private val ready = CompletableDeferred<Boolean>()

    private val targets = listOf(
        LangOption("ur", "Urdu", "اردو"),
        LangOption("en", "English", "English"),
        LangOption("hi", "Hindi", "हिन्दी"),
        LangOption("ar", "Arabic", "العربية"),
        LangOption("tr", "Turkish", "Türkçe"),
        LangOption("es", "Spanish", "Español"),
        LangOption("fr", "French", "Français"),
        LangOption("de", "German", "Deutsch"),
        LangOption("zh", "Chinese", "中文"),
        LangOption("pt", "Portuguese", "Português"),
        LangOption("id", "Indonesian", "Bahasa Indonesia"),
        LangOption("bn", "Bengali", "বাংলা")
    )

    fun start() {
        if (tts != null) return
        tts = TextToSpeech(context.applicationContext) { status ->
            ready.complete(status == TextToSpeech.SUCCESS)
        }
    }

    suspend fun awaitReady(): Boolean = ready.await()

    fun engineName(): String = tts?.defaultEngine ?: "unknown"

    fun maxChunkLength(): Int =
        minOf(TextToSpeech.getMaxSpeechInputLength() - 100, 1200).coerceAtLeast(300)

    /** Languages (from the 12 target languages) that the installed engine can really speak. */
    fun supportedLanguages(): List<LangOption> {
        val t = tts ?: return emptyList()
        val available: Set<Locale> = try { t.availableLanguages ?: emptySet() } catch (e: Exception) { emptySet() }
        return targets.filter { opt ->
            val loc = Locale.forLanguageTag(opt.code)
            available.any { it.language == loc.language } ||
                (available.isEmpty() && t.isLanguageAvailable(loc) >= TextToSpeech.LANG_AVAILABLE)
        }
    }

    fun voicesFor(lang: LangOption): List<VoiceOption> {
        val t = tts ?: return emptyList()
        val loc = Locale.forLanguageTag(lang.code)
        val list = try { t.voices ?: emptySet() } catch (e: Exception) { emptySet() }
        return list.filter { it.locale.language == loc.language }
            .sortedWith(compareByDescending<Voice> { it.quality }.thenBy { it.name })
            .mapIndexed { i, v ->
                val net = if (v.isNetworkConnectionRequired) "online" else "offline"
                VoiceOption(v.name, v, "Voice ${i + 1} - ${v.locale.displayName} ($net)", !v.isNetworkConnectionRequired)
            }
    }

    fun selectVoice(v: VoiceOption?, lang: LangOption) {
        val t = tts ?: return
        if (v != null) t.voice = v.voice else t.language = Locale.forLanguageTag(lang.code)
    }

    /** Live preview (plays through the speaker). */
    fun preview(text: String, rate: Float, pitch: Float, volume: Float) {
        val t = tts ?: return
        t.setSpeechRate(rate)
        t.setPitch(pitch)
        val b = Bundle().apply { putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, volume.coerceIn(0f, 1f)) }
        t.speak(text, TextToSpeech.QUEUE_FLUSH, b, "preview")
    }

    fun stopPreview() { tts?.stop() }

    /** Synthesizes one chunk into a WAV file. Returns true on success. */
    suspend fun synthToFile(text: String, file: File, rate: Float, pitch: Float): Boolean {
        val t = tts ?: return false
        t.setSpeechRate(rate)
        t.setPitch(pitch)
        return try {
            withTimeout(90_000) {
                suspendCancellableCoroutine<Boolean> { cont ->
                    val id = UUID.randomUUID().toString()
                    t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                        override fun onStart(utteranceId: String?) {}
                        override fun onDone(utteranceId: String?) {
                            if (utteranceId == id && cont.isActive) cont.resume(true)
                        }
                        @Deprecated("Deprecated in Java")
                        override fun onError(utteranceId: String?) {
                            if (utteranceId == id && cont.isActive) cont.resume(false)
                        }
                        override fun onError(utteranceId: String?, errorCode: Int) {
                            if (utteranceId == id && cont.isActive) cont.resume(false)
                        }
                    })
                    val r = t.synthesizeToFile(text, Bundle(), file, id)
                    if (r != TextToSpeech.SUCCESS && cont.isActive) cont.resume(false)
                }
            }
        } catch (e: Exception) {
            false
        }
    }

    fun shutdown() {
        tts?.stop(); tts?.shutdown(); tts = null
    }
}
