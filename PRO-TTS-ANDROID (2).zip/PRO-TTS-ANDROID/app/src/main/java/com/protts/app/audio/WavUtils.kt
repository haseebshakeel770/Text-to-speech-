package com.protts.app.audio

import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class WavInfo(val sampleRate: Int, val channels: Int, val dataOffset: Long, val dataLength: Long)

object WavUtils {
    /** Parses a 16-bit PCM WAV header. Returns null if the file is not 16-bit PCM WAV. */
    fun readInfo(file: File): WavInfo? {
        if (!file.exists() || file.length() < 44) return null
        RandomAccessFile(file, "r").use { raf ->
            val hdr = ByteArray(12)
            raf.readFully(hdr)
            if (String(hdr, 0, 4) != "RIFF" || String(hdr, 8, 4) != "WAVE") return null
            var sr = 0; var ch = 0; var bits = 0; var fmtTag = 0
            while (raf.filePointer + 8 <= raf.length()) {
                val ch8 = ByteArray(8)
                raf.readFully(ch8)
                val id = String(ch8, 0, 4)
                val size = ByteBuffer.wrap(ch8, 4, 4).order(ByteOrder.LITTLE_ENDIAN).int.toLong() and 0xFFFFFFFFL
                if (id == "fmt ") {
                    val f = ByteArray(size.toInt())
                    raf.readFully(f)
                    val bb = ByteBuffer.wrap(f).order(ByteOrder.LITTLE_ENDIAN)
                    fmtTag = bb.short.toInt() and 0xFFFF
                    ch = bb.short.toInt()
                    sr = bb.int
                    bb.int; bb.short
                    bits = bb.short.toInt()
                } else if (id == "data") {
                    val start = raf.filePointer
                    val len = if (size == 0L || start + size > raf.length()) raf.length() - start else size
                    if (bits != 16 || (fmtTag != 1 && fmtTag != 0xFFFE) || sr <= 0 || ch <= 0) return null
                    return WavInfo(sr, ch, start, len)
                } else {
                    raf.seek(raf.filePointer + size + (size and 1L))
                }
            }
        }
        return null
    }

    /** Appends the PCM payload of [wav] to [out], multiplied by [gain] (16-bit little endian). */
    fun appendPcm(wav: File, info: WavInfo, out: OutputStream, gain: Float) {
        RandomAccessFile(wav, "r").use { raf ->
            raf.seek(info.dataOffset)
            var remaining = info.dataLength
            val buf = ByteArray(32768)
            while (remaining > 0) {
                val n = raf.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
                if (n <= 0) break
                val even = n - (n % 2)
                if (gain != 1f) applyGain(buf, even, gain)
                out.write(buf, 0, even)
                remaining -= n
            }
        }
    }

    fun applyGain(buf: ByteArray, len: Int, gain: Float) {
        var i = 0
        while (i + 1 < len) {
            val s = (buf[i].toInt() and 0xFF) or (buf[i + 1].toInt() shl 8)
            val v = (s.toShort().toInt() * gain).toInt().coerceIn(-32768, 32767)
            buf[i] = (v and 0xFF).toByte()
            buf[i + 1] = ((v shr 8) and 0xFF).toByte()
            i += 2
        }
    }

    fun writeWavFromPcm(pcm: File, out: File, sampleRate: Int, channels: Int) {
        val dataLen = pcm.length()
        out.outputStream().buffered().use { os ->
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt((36 + dataLen).toInt()); h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(channels.toShort())
            h.putInt(sampleRate); h.putInt(sampleRate * channels * 2); h.putShort((channels * 2).toShort()); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(dataLen.toInt())
            os.write(h.array())
            pcm.inputStream().use { it.copyTo(os) }
        }
    }
}

/** Reads exactly up to buf.size bytes, returns bytes read (0 at end). */
fun InputStream.readFully(buf: ByteArray): Int {
    var total = 0
    while (total < buf.size) {
        val n = read(buf, total, buf.size - total)
        if (n <= 0) break
        total += n
    }
    return total
}
