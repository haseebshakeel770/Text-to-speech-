package com.protts.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Navy = Color(0xFF0A1030)
val NavyLight = Color(0xFF131B4A)
val Purple = Color(0xFF8B3DFF)
val PurpleSoft = Color(0xFFB26BFF)
val Blue = Color(0xFF2F7BFF)
val Cyan = Color(0xFF5AC8FF)
val CardBg = Color(0x1AFFFFFF)

val BgBrush = Brush.verticalGradient(listOf(Navy, Color(0xFF1B1250), Color(0xFF2A1670)))
val AccentBrush = Brush.horizontalGradient(listOf(Blue, Purple))

@Composable
fun ProTtsTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = PurpleSoft, secondary = Cyan, background = Navy, surface = NavyLight,
            onPrimary = Color.White, onSurface = Color.White, onBackground = Color.White
        ),
        content = content
    )
}

@Composable
fun GradientBackground(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(BgBrush), content = content)
}

@Composable
fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .clip(RoundedCornerShape(20.dp))
            .background(CardBg)
            .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(20.dp))
            .padding(16.dp),
        content = content
    )
}

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, enabled: Boolean = true, onClick: () -> Unit) {
    Box(
        modifier
            .fillMaxWidth()
            .height(54.dp)
            .clip(RoundedCornerShape(27.dp))
            .background(if (enabled) AccentBrush else Brush.horizontalGradient(listOf(Color(0xFF444A6B), Color(0xFF444A6B))))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

/** App logo: gradient rounded square with microphone and sound waves (original artwork, drawn in code). */
@Composable
fun ProLogo(size: Dp = 96.dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.minDimension
        drawRoundRect(
            Brush.linearGradient(listOf(Blue, Purple)),
            size = Size(s, s), cornerRadius = CornerRadius(s * 0.26f)
        )
        val w = Color.White
        val cx = s / 2
        // mic capsule
        drawRoundRect(w, Offset(cx - s * 0.09f, s * 0.2f), Size(s * 0.18f, s * 0.34f), CornerRadius(s * 0.09f))
        // cradle
        drawArc(w, 0f, 180f, false, Offset(cx - s * 0.17f, s * 0.3f), Size(s * 0.34f, s * 0.34f),
            style = Stroke(s * 0.035f, cap = StrokeCap.Round))
        drawLine(w, Offset(cx, s * 0.64f), Offset(cx, s * 0.76f), s * 0.035f, StrokeCap.Round)
        drawLine(w, Offset(cx - s * 0.1f, s * 0.76f), Offset(cx + s * 0.1f, s * 0.76f), s * 0.035f, StrokeCap.Round)
        // sound waves
        for ((i, h) in listOf(0.10f, 0.18f).withIndex()) {
            val d = s * (0.27f + 0.09f * i)
            drawArc(Color(0xCCFFFFFF), -50f, 100f, false, Offset(cx - d, s * 0.45f - d), Size(d * 2, d * 2),
                style = Stroke(s * 0.03f, cap = StrokeCap.Round))
            drawArc(Color(0xCCFFFFFF), 130f, 100f, false, Offset(cx - d, s * 0.45f - d), Size(d * 2, d * 2),
                style = Stroke(s * 0.03f, cap = StrokeCap.Round))
        }
    }
}
