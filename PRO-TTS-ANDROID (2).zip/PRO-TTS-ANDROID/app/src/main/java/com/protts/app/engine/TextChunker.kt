package com.protts.app.engine

/** Splits long text into chunks on sentence boundaries (never mid-sentence unless a sentence is longer than maxLen). */
object TextChunker {
    private val terminators = setOf('.', '!', '?', '\u06D4' /* ۔ */, '\u061F' /* ؟ */, '\u0964' /* । */, '\n')

    fun split(text: String, maxLen: Int): List<String> {
        val sentences = ArrayList<String>()
        val sb = StringBuilder()
        for (ch in text.replace("\r", "")) {
            sb.append(ch)
            if (ch in terminators) {
                sentences.add(sb.toString()); sb.clear()
            }
        }
        if (sb.isNotBlank()) sentences.add(sb.toString())

        val chunks = ArrayList<String>()
        val cur = StringBuilder()
        fun flush() { if (cur.isNotBlank()) chunks.add(cur.toString().trim()); cur.clear() }

        for (s in sentences) {
            if (s.length > maxLen) {
                flush()
                var rest = s
                while (rest.length > maxLen) {
                    var cut = rest.lastIndexOf(' ', maxLen)
                    if (cut <= 0) cut = maxLen
                    chunks.add(rest.substring(0, cut).trim())
                    rest = rest.substring(cut)
                }
                if (rest.isNotBlank()) cur.append(rest)
            } else {
                if (cur.length + s.length > maxLen) flush()
                cur.append(s)
            }
        }
        flush()
        // drop chunks with nothing speakable
        return chunks.filter { c -> c.any { it.isLetterOrDigit() } }
    }
}
