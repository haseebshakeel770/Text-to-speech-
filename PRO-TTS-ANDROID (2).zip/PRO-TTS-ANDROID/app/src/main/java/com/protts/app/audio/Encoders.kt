package com.protts.app.audio

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import java.io.File
import java.io.FileOutputStream

/**
 * MP3 encoding through the LAME library (com.github.NorthernCaptain:TAndroidLame, LGPL).
 * Accessed via reflection so that a different wrapper version can never break compilation;
 * if anything about the library is unavailable, callers fall back to AAC (.m4a).
 */
object Mp3Encoder {
    private const val PKG = "com.naman14.androidlame."

    fun encode(pcm: File, sampleRate: Int, channels: Int, out: File, onProgress: (Float) -> Unit) {
        val builderCls = Class.forName(PKG + "LameBuilder")
        var builder: Any = builderCls.getDeclaredConstructor().newInstance()
        val int = Int::class.javaPrimitiveType!!
        fun set(name: String, v: Int) {
            builder = builderCls.getMethod(name, int).invoke(builder)!!
        }
        set("setInSampleRate", sampleRate)
        set("setOutChannels", 1)
        set("setOutBitrate", 128)
        set("setOutSampleRate", sampleRate)
        set("setQuality", 2)
        val lame = builderCls.getMethod("build").invoke(builder)!!
        val lameCls = lame.javaClass
        val shortArr = ShortArray(0).javaClass
        val encode = lameCls.getMethod("encode", shortArr, shortArr, int, ByteArray::class.java)
        val flush = lameCls.getMethod("flush", ByteArray::class.java)
        val close = lameCls.getMethod("close")

        val total = pcm.length().coerceAtLeast(1)
        var done = 0L
        val frameBytes = 2 * channels
        val samplesPerBlock = 8192
        val block = ByteArray(samplesPerBlock * frameBytes)
        val mp3buf = ByteArray((7200 + samplesPerBlock * 1.25).toInt())
        FileOutputStream(out).buffered().use { os ->
            pcm.inputStream().buffered().use { ins ->
                while (true) {
                    val n = ins.readFully(block)
                    if (n <= 0) break
                    val frames = n / frameBytes
                    val mono = ShortArray(frames)
                    for (i in 0 until frames) {
                        var sum = 0
                        for (c in 0 until channels) {
                            val idx = i * frameBytes + c * 2
                            sum += ((block[idx].toInt() and 0xFF) or (block[idx + 1].toInt() shl 8)).toShort().toInt()
                        }
                        mono[i] = (sum / channels).toShort()
                    }
                    val w = encode.invoke(lame, mono, mono, frames, mp3buf) as Int
                    if (w < 0) throw IllegalStateException("LAME error $w")
                    if (w > 0) os.write(mp3buf, 0, w)
                    done += n
                    onProgress(done.toFloat() / total)
                }
                val w = flush.invoke(lame, mp3buf) as Int
                if (w > 0) os.write(mp3buf, 0, w)
            }
        }
        close.invoke(lame)
    }
}

/** AAC-in-MP4 (.m4a) using Android's built-in MediaCodec - always available, real encoding. */
object AacEncoder {
    fun encode(pcm: File, sampleRate: Int, channels: Int, out: File, onProgress: (Float) -> Unit) {
        val format = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, sampleRate, channels).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 96_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val codec = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        codec.configure(format, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        codec.start()
        val muxer = MediaMuxer(out.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        var track = -1
        var muxerStarted = false
        val info = MediaCodec.BufferInfo()
        val frameBytes = 2 * channels
        val total = pcm.length().coerceAtLeast(1)
        var consumed = 0L
        var inputDone = false
        try {
            pcm.inputStream().buffered().use { ins ->
                var loop = true
                while (loop) {
                    if (!inputDone) {
                        val ii = codec.dequeueInputBuffer(10_000)
                        if (ii >= 0) {
                            val buf = codec.getInputBuffer(ii)!!
                            buf.clear()
                            val want = buf.remaining() - (buf.remaining() % frameBytes)
                            val tmp = ByteArray(want)
                            val n = ins.readFully(tmp)
                            val pts = consumed / frameBytes * 1_000_000L / sampleRate
                            if (n <= 0) {
                                codec.queueInputBuffer(ii, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                buf.put(tmp, 0, n)
                                codec.queueInputBuffer(ii, 0, n, pts, 0)
                                consumed += n
                                onProgress(consumed.toFloat() / total)
                            }
                        }
                    }
                    val oi = codec.dequeueOutputBuffer(info, 10_000)
                    when {
                        oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            track = muxer.addTrack(codec.outputFormat)
                            muxer.start(); muxerStarted = true
                        }
                        oi >= 0 -> {
                            val ob = codec.getOutputBuffer(oi)!!
                            if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) info.size = 0
                            if (info.size > 0 && muxerStarted) {
                                ob.position(info.offset)
                                ob.limit(info.offset + info.size)
                                muxer.writeSampleData(track, ob, info)
                            }
                            codec.releaseOutputBuffer(oi, false)
                            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) loop = false
                        }
                    }
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) {}
            codec.release()
            try { if (muxerStarted) muxer.stop() } catch (_: Exception) {}
            muxer.release()
        }
    }
}
