package com.protts.app.ui

import android.content.ActivityNotFoundException
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.speech.tts.TextToSpeech
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.protts.app.MainViewModel
import com.protts.app.data.AudioItem
import kotlinx.coroutines.delay

private val fieldColors
    @Composable get() = OutlinedTextFieldDefaults.colors(
        focusedTextColor = Color.White, unfocusedTextColor = Color.White,
        focusedBorderColor = PurpleSoft, unfocusedBorderColor = Color(0x55FFFFFF),
        cursorColor = Cyan
    )

private fun openSystemTtsSettings(ctx: Context) {
    try {
        ctx.startActivity(Intent("com.android.settings.TTS_SETTINGS").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        try {
            ctx.startActivity(Intent(android.provider.Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (_: Exception) {}
    }
}

private fun installVoiceData(ctx: Context) {
    try {
        ctx.startActivity(Intent(TextToSpeech.Engine.ACTION_INSTALL_TTS_DATA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: ActivityNotFoundException) {
        openSystemTtsSettings(ctx)
    }
}

// ---------------------------------------------------------------- A. Splash
@Composable
fun SplashScreen(onDone: () -> Unit) {
    LaunchedEffect(Unit) { delay(1400); onDone() }
    GradientBackground {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            ProLogo(120.dp)
            Spacer(Modifier.height(20.dp))
            Text("PRO TTS", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            Text("AI Voice Studio", color = Cyan, fontSize = 15.sp)
        }
    }
}

// ---------------------------------------------------------------- B. Onboarding
@Composable
fun OnboardingScreen(onFinish: () -> Unit) {
    val pages = listOf(
        "Type or paste any text" to "Stories, articles, book pages - even thousands of words. PRO TTS splits long text automatically.",
        "Real voices, your device" to "PRO TTS uses the text-to-speech engine installed on your phone. Only languages and voices it really supports are shown.",
        "Save as MP3" to "Export your audio, share it, and keep a library of everything you create. No paid services needed."
    )
    var i by remember { mutableIntStateOf(0) }
    GradientBackground {
        Column(Modifier.fillMaxSize().systemBarsPadding().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Spacer(Modifier.weight(1f))
            ProLogo(90.dp)
            Spacer(Modifier.height(24.dp))
            Text(pages[i].first, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Text(pages[i].second, color = Color(0xFFD8DCFF), fontSize = 15.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.weight(1f))
            Text("${i + 1} / ${pages.size}", color = Color(0xAAFFFFFF))
            Spacer(Modifier.height(12.dp))
            GradientButton(if (i == pages.lastIndex) "Get Started" else "Next") {
                if (i == pages.lastIndex) onFinish() else i++
            }
        }
    }
}

// ---------------------------------------------------------------- Player controls (shared)
@Composable
fun PlayerControls(vm: MainViewModel) {
    val p = vm.player
    val item = vm.current
    val loaded = item != null && p.loadedPath == item.path
    LaunchedEffect(loaded) { while (true) { delay(250); p.tick() } }
    GlassCard(Modifier.fillMaxWidth()) {
        Text(item?.name ?: "No audio yet", color = Color.White, fontWeight = FontWeight.Bold)
        Text(
            if (item == null) "Convert some text to speech first." else "${item.language} - ${item.format.uppercase()}",
            color = Color(0xAAFFFFFF), fontSize = 12.sp
        )
        val dur = p.durationMs.coerceAtLeast(1)
        Slider(
            value = if (loaded) p.positionMs.toFloat().coerceIn(0f, dur.toFloat()) else 0f,
            onValueChange = { if (loaded) p.seekTo(it.toInt()) },
            valueRange = 0f..dur.toFloat(), enabled = loaded
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(if (loaded) p.positionMs.toLong() else 0), color = Color.White, fontSize = 12.sp)
            Text(formatTime(if (loaded) p.durationMs.toLong() else 0), color = Color.White, fontSize = 12.sp)
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { p.backward() }, enabled = loaded) { Icon(Icons.Default.Replay10, "Back 10s", tint = Color.White) }
            IconButton(onClick = { p.restart() }, enabled = loaded) { Icon(Icons.Default.Replay, "Restart", tint = Color.White) }
            FilledIconButton(onClick = { if (p.isPlaying) p.pause() else p.play() }, enabled = loaded) {
                Icon(if (p.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (p.isPlaying) "Pause" else "Play")
            }
            IconButton(onClick = { p.stop() }, enabled = loaded) { Icon(Icons.Default.Stop, "Stop", tint = Color.White) }
            IconButton(onClick = { p.forward() }, enabled = loaded) { Icon(Icons.Default.Forward10, "Forward 10s", tint = Color.White) }
        }
    }
}

// ---------------------------------------------------------------- C. Dashboard
@Composable
fun DashboardScreen(vm: MainViewModel, nav: (String) -> Unit, export: (AudioItem) -> Unit) {
    val ctx = LocalContext.current
    ScreenFrame("PRO TTS", null) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            ProLogo(48.dp)
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Welcome to PRO TTS", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("Turn any text into speech", color = Cyan, fontSize = 13.sp)
            }
        }
        vm.engineError?.let { GlassCard(Modifier.fillMaxWidth()) { Body(it) } }
        OutlinedTextField(
            value = vm.text, onValueChange = { vm.text = it },
            modifier = Modifier.fillMaxWidth(), minLines = 6, maxLines = 10,
            label = { Text("Type or paste your text") }, colors = fieldColors
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("${vm.text.length} characters", color = Color(0xAAFFFFFF), fontSize = 12.sp)
            Row {
                TextButton(onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val t = cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                    if (t.isNotEmpty()) vm.text += t
                }) { Text("Paste") }
                TextButton(onClick = { vm.text = "" }) { Text("Clear") }
                TextButton(onClick = { nav("editor") }) { Text("Full editor") }
            }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            GlassCard(Modifier.weight(1f).clickable { nav("languages") }) {
                Text("Language", color = Color(0xAAFFFFFF), fontSize = 11.sp)
                Text(vm.selectedLang?.let { "${it.name}" } ?: "None available", color = Color.White, fontWeight = FontWeight.Bold)
            }
            GlassCard(Modifier.weight(1f).clickable { nav("voices") }) {
                Text("Voice", color = Color(0xAAFFFFFF), fontSize = 11.sp)
                Text(vm.selectedVoice?.let { "${vm.voices.indexOf(it) + 1} of ${vm.voices.size}" } ?: "Default", color = Color.White, fontWeight = FontWeight.Bold)
            }
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Speed: %.2fx".format(vm.rate), color = Color.White, fontSize = 13.sp)
            Slider(vm.rate, { vm.rate = it }, valueRange = 0.5f..2f)
            Text("Pitch: %.2f".format(vm.pitch), color = Color.White, fontSize = 13.sp)
            Slider(vm.pitch, { vm.pitch = it }, valueRange = 0.5f..2f)
            Text("Volume: %d%%".format((vm.volume * 100).toInt()), color = Color.White, fontSize = 13.sp)
            Slider(vm.volume, { vm.volume = it }, valueRange = 0.2f..2f)
            TextButton(onClick = { vm.preview() }) { Text("Preview voice") }
        }
        GradientButton(if (vm.busy) "Converting..." else "Convert To Speech", enabled = !vm.busy) { vm.convert() }
        if (vm.busy) LinearProgressIndicator(progress = { vm.progress }, modifier = Modifier.fillMaxWidth())
        if (vm.status.isNotEmpty()) Text(vm.status, color = Cyan, fontSize = 13.sp)
        PlayerControls(vm)
        OutlinedButton(onClick = { vm.current?.let(export) }, enabled = vm.current != null, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.Save, null); Spacer(Modifier.width(8.dp)); Text("Save Audio")
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            TextButton(onClick = { nav("library") }) { Icon(Icons.Default.LibraryMusic, null); Spacer(Modifier.width(4.dp)); Text("Library") }
            TextButton(onClick = { nav("history") }) { Icon(Icons.Default.History, null); Spacer(Modifier.width(4.dp)); Text("History") }
            TextButton(onClick = { nav("settings") }) { Icon(Icons.Default.Settings, null); Spacer(Modifier.width(4.dp)); Text("Settings") }
        }
        Spacer(Modifier.height(16.dp))
    }
}

// ---------------------------------------------------------------- D. Text editor
@Composable
fun EditorScreen(vm: MainViewModel, back: () -> Unit) {
    val ctx = LocalContext.current
    ScreenFrame("Text Editor", back, scroll = false) {
        OutlinedTextField(
            value = vm.text, onValueChange = { vm.text = it },
            modifier = Modifier.fillMaxWidth().weight(1f),
            label = { Text("Your text (paste long articles here)") }, colors = fieldColors,
            keyboardOptions = KeyboardOptions.Default
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("${vm.text.length} characters - ${vm.text.split(Regex("\\s+")).count { it.isNotBlank() }} words", color = Color(0xAAFFFFFF), fontSize = 12.sp)
            Row {
                TextButton(onClick = {
                    val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val t = cm.primaryClip?.getItemAt(0)?.coerceToText(ctx)?.toString().orEmpty()
                    if (t.isNotEmpty()) vm.text += t
                }) { Icon(Icons.Default.ContentPaste, null); Spacer(Modifier.width(4.dp)); Text("Paste") }
                TextButton(onClick = { vm.text = "" }) { Text("Clear") }
            }
        }
        GradientButton("Done", Modifier.padding(bottom = 12.dp)) { back() }
    }
}

// ---------------------------------------------------------------- E. Language selection
@Composable
fun LanguageScreen(vm: MainViewModel, back: () -> Unit) {
    val ctx = LocalContext.current
    ScreenFrame("Select Language", back) {
        Body("Only languages that your phone's speech engine (${vm.engineName.ifEmpty { "none" }}) really supports are listed.")
        if (vm.languages.isEmpty()) {
            GlassCard(Modifier.fillMaxWidth()) {
                Body("No supported languages were found yet. Install voice data for your engine, then come back.")
            }
        }
        vm.languages.forEach { l ->
            GlassCard(Modifier.fillMaxWidth().clickable { vm.selectLanguage(l); back() }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(l.name, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(l.nativeName, color = Cyan, fontSize = 13.sp)
                    }
                    if (vm.selectedLang?.code == l.code) Icon(Icons.Default.Check, null, tint = Cyan)
                }
            }
        }
        OutlinedButton(onClick = { installVoiceData(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("Install / download voice data") }
        OutlinedButton(onClick = { openSystemTtsSettings(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("Open system TTS settings") }
        TextButton(onClick = { vm.refreshLanguages() }) { Text("Refresh list") }
        Body("Urdu note: Urdu is listed only if your installed engine reports it. If it is missing, install an engine/voice that supports Urdu (for example Google Speech Services voice data, if available for your device).")
    }
}

// ---------------------------------------------------------------- F. Voice selection
@Composable
fun VoiceScreen(vm: MainViewModel, back: () -> Unit) {
    ScreenFrame("Select Voice", back) {
        Body("Voices below are the real voices reported by your speech engine for ${vm.selectedLang?.name ?: "the selected language"}. Android does not expose a reliable male/female flag, so no gender labels are invented - use Preview to hear each one.")
        if (vm.voices.isEmpty()) GlassCard(Modifier.fillMaxWidth()) { Body("No separate voices reported - the engine's default voice will be used.") }
        vm.voices.forEach { v ->
            GlassCard(Modifier.fillMaxWidth()) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f).clickable { vm.selectVoice(v); back() }) {
                        Text(v.label, color = Color.White, fontWeight = FontWeight.Bold)
                        Text(v.id, color = Color(0xAAFFFFFF), fontSize = 11.sp)
                    }
                    if (vm.selectedVoice?.id == v.id) Icon(Icons.Default.Check, null, tint = Cyan)
                    IconButton(onClick = { vm.preview(v) }) { Icon(Icons.Default.PlayArrow, "Preview", tint = Color.White) }
                }
            }
        }
    }
}

// ---------------------------------------------------------------- G. Audio player
@Composable
fun PlayerScreen(vm: MainViewModel, back: () -> Unit, export: (AudioItem) -> Unit, share: (AudioItem) -> Unit) {
    ScreenFrame("Audio Player", back) {
        PlayerControls(vm)
        val item = vm.current
        if (item != null) {
            GlassCard(Modifier.fillMaxWidth()) {
                Body("Voice: ${item.voiceName}\nCreated: ${formatDate(item.createdAt)}\nSize: ${formatSize(item.sizeBytes)}")
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { export(item) }, modifier = Modifier.weight(1f)) { Text("Save / Export") }
                OutlinedButton(onClick = { share(item) }, modifier = Modifier.weight(1f)) { Text("Share") }
            }
        }
    }
}

// ---------------------------------------------------------------- H. Library
@Composable
fun LibraryScreen(vm: MainViewModel, nav: (String) -> Unit, back: () -> Unit, export: (AudioItem) -> Unit, share: (AudioItem) -> Unit) {
    val items by vm.library.collectAsState()
    var renaming by remember { mutableStateOf<AudioItem?>(null) }
    var deleting by remember { mutableStateOf<AudioItem?>(null) }
    ScreenFrame("Audio Library", back) {
        if (items.isEmpty()) Body("Your audios will appear here.")
        items.forEach { a ->
            GlassCard(Modifier.fillMaxWidth()) {
                Text(a.name, color = Color.White, fontWeight = FontWeight.Bold)
                Body("${a.language} - ${a.voiceName}\n${formatDate(a.createdAt)} - ${formatTime(a.durationMs)} - ${formatSize(a.sizeBytes)} - ${a.format.uppercase()}")
                Row {
                    IconButton(onClick = { if (vm.open(a)) { vm.player.play(); nav("player") } }) { Icon(Icons.Default.PlayArrow, "Play", tint = Color.White) }
                    IconButton(onClick = { renaming = a }) { Icon(Icons.Default.Edit, "Rename", tint = Color.White) }
                    IconButton(onClick = { share(a) }) { Icon(Icons.Default.Share, "Share", tint = Color.White) }
                    IconButton(onClick = { export(a) }) { Icon(Icons.Default.Download, "Save", tint = Color.White) }
                    IconButton(onClick = { deleting = a }) { Icon(Icons.Default.Delete, "Delete", tint = Color.White) }
                }
            }
        }
    }
    renaming?.let { a ->
        var n by remember(a.id) { mutableStateOf(a.name) }
        AlertDialog(
            onDismissRequest = { renaming = null },
            title = { Text("Rename audio") },
            text = { OutlinedTextField(n, { n = it }, singleLine = true) },
            confirmButton = { TextButton(onClick = { vm.rename(a, n); renaming = null }) { Text("Save") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Cancel") } }
        )
    }
    deleting?.let { a ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("Delete audio?") },
            text = { Text("\"${a.name}\" will be permanently deleted.") },
            confirmButton = { TextButton(onClick = { vm.delete(a); deleting = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { deleting = null }) { Text("Cancel") } }
        )
    }
}

// ---------------------------------------------------------------- I. History
@Composable
fun HistoryScreen(vm: MainViewModel, back: () -> Unit, nav: (String) -> Unit) {
    val items by vm.library.collectAsState()
    ScreenFrame("Audio History", back) {
        if (items.isEmpty()) Body("No history yet.")
        items.forEach { a ->
            GlassCard(Modifier.fillMaxWidth().clickable { vm.text = a.textPreview; nav("editor") }) {
                Text(formatDate(a.createdAt) + " - " + a.language, color = Cyan, fontSize = 12.sp)
                Body(a.textPreview)
                Text("Tap to reuse this text", color = Color(0x88FFFFFF), fontSize = 11.sp)
            }
        }
    }
}

// ---------------------------------------------------------------- J. Settings
@Composable
fun SettingsScreen(vm: MainViewModel, back: () -> Unit, nav: (String) -> Unit) {
    val ctx = LocalContext.current
    ScreenFrame("Settings", back) {
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Output format", color = Color.White, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("mp3" to "MP3", "m4a" to "M4A (AAC)", "wav" to "WAV").forEach { (k, label) ->
                    FilterChip(selected = vm.outputFormat == k, onClick = { vm.setFormat(k) }, label = { Text(label) })
                }
            }
            Body("MP3 uses the LAME encoder. If it is unavailable on your build, PRO TTS tells you and saves M4A (AAC) instead.")
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Speech engine", color = Color.White, fontWeight = FontWeight.Bold)
            Body("Active engine: ${vm.engineName.ifEmpty { "not ready" }}\nOffline use works when your engine has offline voice data installed (voices marked 'offline').")
            OutlinedButton(onClick = { openSystemTtsSettings(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("Engine & voice settings") }
            OutlinedButton(onClick = { installVoiceData(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("Download voice data") }
        }
        OutlinedButton(onClick = { nav("about") }, modifier = Modifier.fillMaxWidth()) { Text("About PRO TTS") }
        OutlinedButton(onClick = { nav("help") }, modifier = Modifier.fillMaxWidth()) { Text("Help and Support") }
    }
}

// ---------------------------------------------------------------- K. About
@Composable
fun AboutScreen(back: () -> Unit) {
    ScreenFrame("About PRO TTS", back) {
        Row(verticalAlignment = Alignment.CenterVertically) { ProLogo(64.dp); Spacer(Modifier.width(12.dp)); Text("PRO TTS 1.0.0", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold) }
        Body("PRO TTS converts text to speech using the free text-to-speech engine on your device. No paid APIs, no subscriptions, no accounts.")
        Body("Open-source components: Kotlin, Jetpack Compose, Room, AndroidX (Apache-2.0) and the LAME MP3 encoder wrapper (LGPL). See THIRD_PARTY_NOTICES in the project.")
    }
}

// ---------------------------------------------------------------- L. Help
@Composable
fun HelpScreen(back: () -> Unit) {
    val ctx = LocalContext.current
    ScreenFrame("Help and Support", back) {
        Body("1. Type or paste text on the home screen.\n2. Choose a language and voice.\n3. Adjust speed, pitch and volume.\n4. Tap Convert To Speech.\n5. Play, then Save Audio to choose where the file is stored.")
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Language or voice missing?", color = Color.White, fontWeight = FontWeight.Bold)
            Body("The list comes from your phone's speech engine. Install a TTS engine/voice data for that language in system settings, then tap 'Refresh list' on the language screen.")
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Text("Conversion fails?", color = Color.White, fontWeight = FontWeight.Bold)
            Body("Try a shorter text, a different voice, or make sure the voice data is fully downloaded. Some online voices cannot be saved to a file.")
        }
        OutlinedButton(onClick = { openSystemTtsSettings(ctx) }, modifier = Modifier.fillMaxWidth()) { Text("Open system TTS settings") }
    }
}
