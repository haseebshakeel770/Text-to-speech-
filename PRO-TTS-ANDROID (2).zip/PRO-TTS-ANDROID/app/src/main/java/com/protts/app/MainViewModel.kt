package com.protts.app

import android.app.Application
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.FileProvider
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.protts.app.audio.*
import com.protts.app.data.AppDb
import com.protts.app.data.AudioItem
import com.protts.app.engine.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDb.get(app).dao()
    private val engine = TtsEngine(app)
    private val prefs = app.getSharedPreferences("protts", Context.MODE_PRIVATE)
    val player = AudioPlayer()

    val library = dao.all().stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    var text by mutableStateOf("")
    var engineReady by mutableStateOf(false)
    var engineError by mutableStateOf<String?>(null)
    var engineName by mutableStateOf("")
    var languages by mutableStateOf<List<LangOption>>(emptyList())
    var selectedLang by mutableStateOf<LangOption?>(null)
    var voices by mutableStateOf<List<VoiceOption>>(emptyList())
    var selectedVoice by mutableStateOf<VoiceOption?>(null)
    var rate by mutableFloatStateOf(1f)
    var pitch by mutableFloatStateOf(1f)
    var volume by mutableFloatStateOf(1f)
    var busy by mutableStateOf(false)
    var progress by mutableFloatStateOf(0f)
    var status by mutableStateOf("")
    var current by mutableStateOf<AudioItem?>(null)
    var outputFormat by mutableStateOf(prefs.getString("format", "mp3") ?: "mp3")
    var onboardingDone by mutableStateOf(prefs.getBoolean("onboarded", false))
    var pendingExport: AudioItem? = null

    init {
        engine.start()
        viewModelScope.launch {
            val ok = engine.awaitReady()
            if (!ok) {
                engineError = "No text-to-speech engine could be started. Install one (e.g. Google Speech Services or eSpeak NG) in Android settings."
                return@launch
            }
            engineReady = true
            engineName = engine.engineName()
            refreshLanguages()
        }
    }

    fun refreshLanguages() {
        languages = engine.supportedLanguages()
        val keep = selectedLang?.let { s -> languages.find { it.code == s.code } }
        selectLanguage(keep ?: languages.firstOrNull { it.code == "en" } ?: languages.firstOrNull())
    }

    fun selectLanguage(l: LangOption?) {
        selectedLang = l
        voices = if (l != null) engine.voicesFor(l) else emptyList()
        selectVoice(voices.firstOrNull(), l)
    }

    fun selectVoice(v: VoiceOption?, l: LangOption? = selectedLang) {
        selectedVoice = v
        if (l != null) engine.selectVoice(v, l)
    }

    fun previewSample(): String = when (selectedLang?.code) {
        "ur" -> "یہ پرو ٹی ٹی ایس کی آواز کا نمونہ ہے۔"
        "hi" -> "यह प्रो टी टी एस की आवाज़ का नमूना है।"
        "ar" -> "هذا نموذج لصوت التطبيق."
        "tr" -> "Bu, uygulamanın ses örneğidir."
        "es" -> "Esta es una muestra de la voz."
        "fr" -> "Ceci est un échantillon de la voix."
        "de" -> "Dies ist eine Stimmprobe."
        "zh" -> "这是语音示例。"
        "pt" -> "Esta é uma amostra da voz."
        "id" -> "Ini adalah contoh suara."
        "bn" -> "এটি কণ্ঠস্বরের একটি নমুনা।"
        else -> "This is a sample of the PRO TTS voice."
    }

    fun preview(v: VoiceOption? = selectedVoice) {
        val l = selectedLang ?: return
        engine.selectVoice(v, l)
        engine.preview(previewSample(), rate, pitch, volume)
    }

    fun stopPreview() = engine.stopPreview()

    fun setFormat(f: String) { outputFormat = f; prefs.edit().putString("format", f).apply() }
    fun finishOnboarding() { onboardingDone = true; prefs.edit().putBoolean("onboarded", true).apply() }

    fun convert() {
        val lang = selectedLang
        if (text.isBlank()) { status = "Please type or paste some text first."; return }
        if (!engineReady || lang == null) { status = engineError ?: "Speech engine is not ready yet."; return }
        if (busy) return
        engine.stopPreview()
        engine.selectVoice(selectedVoice, lang)
        busy = true; progress = 0f; status = "Preparing..."
        val fmtWanted = outputFormat
        val input = text
        viewModelScope.launch {
            try {
                val item = withContext(Dispatchers.IO) { generate(input, lang, fmtWanted) }
                current = item
                if (player.load(item.path)) status = "Done - ${item.format.uppercase()} saved to your library."
                else status = "Audio created but could not be loaded in the player."
            } catch (e: Exception) {
                status = "Conversion failed: ${e.message ?: e.javaClass.simpleName}"
            } finally {
                busy = false
            }
        }
    }

    private suspend fun generate(input: String, lang: LangOption, fmtWanted: String): AudioItem {
        val ctx = getApplication<Application>()
        val chunks = TextChunker.split(input, engine.maxChunkLength())
        if (chunks.isEmpty()) error("The text has nothing speakable.")
        val tmp = File(ctx.cacheDir, "chunks").apply { deleteRecursively(); mkdirs() }
        val pcmFile = File(tmp, "all.pcm")
        var sr = 0; var ch = 0
        FileOutputStream(pcmFile).buffered().use { out ->
            chunks.forEachIndexed { i, c ->
                withContext(Dispatchers.Main) { status = "Speaking part ${i + 1} of ${chunks.size}..." }
                val wav = File(tmp, "c$i.wav")
                if (!engine.synthToFile(c, wav, rate, pitch)) error("The speech engine failed on part ${i + 1}.")
                val info = WavUtils.readInfo(wav) ?: error("The engine produced audio in an unsupported format.")
                if (sr == 0) { sr = info.sampleRate; ch = info.channels }
                else if (sr != info.sampleRate || ch != info.channels) error("The engine changed audio format between parts.")
                WavUtils.appendPcm(wav, info, out, volume)
                wav.delete()
                withContext(Dispatchers.Main) { progress = (i + 1f) / chunks.size * 0.8f }
            }
        }
        val dir = File(ctx.filesDir, "audio").apply { mkdirs() }
        val stamp = System.currentTimeMillis()
        var fmt = fmtWanted
        var note = ""
        var outFile = File(dir, "pro_tts_$stamp.$fmt")
        withContext(Dispatchers.Main) { status = "Encoding ${fmt.uppercase()}..." }
        val prog: (Float) -> Unit = { p -> viewModelScope.launch(Dispatchers.Main) { progress = 0.8f + p * 0.2f } }
        when (fmt) {
            "mp3" -> try {
                Mp3Encoder.encode(pcmFile, sr, ch, outFile, prog)
            } catch (t: Throwable) {
                outFile.delete(); fmt = "m4a"; note = " (MP3 encoder unavailable - saved as M4A/AAC)"
                outFile = File(dir, "pro_tts_$stamp.m4a")
                AacEncoder.encode(pcmFile, sr, ch, outFile, prog)
            }
            "m4a" -> AacEncoder.encode(pcmFile, sr, ch, outFile, prog)
            else -> WavUtils.writeWavFromPcm(pcmFile, outFile, sr, ch)
        }
        val durationMs = pcmFile.length() * 1000L / (sr * ch * 2L)
        tmp.deleteRecursively()
        val name = input.trim().replace(Regex("\\s+"), " ").take(28).ifBlank { "Audio" }
        val item = AudioItem(
            name = name, path = outFile.absolutePath, format = fmt,
            language = lang.name, voiceName = selectedVoice?.id ?: "default",
            createdAt = stamp, durationMs = durationMs, sizeBytes = outFile.length(),
            textPreview = input.trim().take(120)
        )
        val id = dao.insert(item)
        if (note.isNotEmpty()) withContext(Dispatchers.Main) { status = note }
        return item.copy(id = id)
    }

    fun open(item: AudioItem): Boolean {
        current = item
        val ok = player.load(item.path)
        if (!ok) status = "Could not open this audio file."
        return ok
    }

    fun rename(item: AudioItem, newName: String) = viewModelScope.launch {
        val n = newName.trim().ifBlank { return@launch }
        dao.update(item.copy(name = n))
        if (current?.id == item.id) current = item.copy(name = n)
    }

    fun delete(item: AudioItem) = viewModelScope.launch {
        if (current?.id == item.id) { player.release(); current = null }
        withContext(Dispatchers.IO) { File(item.path).delete() }
        dao.delete(item)
    }

    fun exportTo(uri: Uri) {
        val item = pendingExport ?: return
        pendingExport = null
        viewModelScope.launch {
            val ok = withContext(Dispatchers.IO) {
                try {
                    getApplication<Application>().contentResolver.openOutputStream(uri)?.use { o ->
                        File(item.path).inputStream().use { it.copyTo(o) }
                    } != null
                } catch (e: Exception) { false }
            }
            status = if (ok) "Audio saved successfully." else "Saving failed."
        }
    }

    fun shareIntent(item: AudioItem): Intent {
        val ctx = getApplication<Application>()
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", File(item.path))
        val mime = when (item.format) { "mp3" -> "audio/mpeg"; "m4a" -> "audio/mp4"; else -> "audio/wav" }
        return Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }, "Share audio").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    }

    override fun onCleared() {
        player.release()
        engine.shutdown()
    }
}
