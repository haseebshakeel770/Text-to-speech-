package com.protts.app.data

import android.content.Context
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Entity(tableName = "audios")
data class AudioItem(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val path: String,
    val format: String,          // "mp3", "m4a" or "wav"
    val language: String,
    val voiceName: String,
    val createdAt: Long,
    val durationMs: Long,
    val sizeBytes: Long,
    val textPreview: String
)

@Dao
interface AudioDao {
    @Query("SELECT * FROM audios ORDER BY createdAt DESC")
    fun all(): Flow<List<AudioItem>>

    @Insert
    suspend fun insert(item: AudioItem): Long

    @Update
    suspend fun update(item: AudioItem)

    @Delete
    suspend fun delete(item: AudioItem)
}

@Database(entities = [AudioItem::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AudioDao

    companion object {
        @Volatile private var inst: AppDb? = null
        fun get(ctx: Context): AppDb = inst ?: synchronized(this) {
            inst ?: Room.databaseBuilder(ctx.applicationContext, AppDb::class.java, "protts.db")
                .build().also { inst = it }
        }
    }
}
