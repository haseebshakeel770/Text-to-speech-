package com.protts.app.audio

import android.media.MediaPlayer
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Thin MediaPlayer wrapper that exposes Compose state for the UI. */
class AudioPlayer {
    private var mp: MediaPlayer? = null
    var loadedPath by mutableStateOf<String?>(null); private set
    var isPlaying by mutableStateOf(false); private set
    var positionMs by mutableIntStateOf(0); private set
    var durationMs by mutableIntStateOf(0); private set

    fun load(path: String): Boolean {
        release()
        return try {
            val p = MediaPlayer()
            p.setDataSource(path)
            p.prepare()
            p.setOnCompletionListener { isPlaying = false; positionMs = durationMs }
            mp = p
            durationMs = p.duration
            positionMs = 0
            loadedPath = path
            true
        } catch (e: Exception) {
            false
        }
    }

    fun play() {
        val p = mp ?: return
        if (positionMs >= durationMs - 50) { p.seekTo(0); positionMs = 0 }
        p.start(); isPlaying = true
    }
    fun pause() { mp?.pause(); isPlaying = false }
    fun resume() = play()
    fun stop() { mp?.let { it.pause(); it.seekTo(0) }; positionMs = 0; isPlaying = false }
    fun restart() { mp?.seekTo(0); positionMs = 0; play() }
    fun seekTo(ms: Int) { val p = mp ?: return; val t = ms.coerceIn(0, durationMs); p.seekTo(t); positionMs = t }
    fun forward() = seekTo(positionMs + 10_000)
    fun backward() = seekTo(positionMs - 10_000)
    fun tick() { mp?.let { if (isPlaying) positionMs = it.currentPosition } }

    fun release() {
        try { mp?.release() } catch (_: Exception) {}
        mp = null; isPlaying = false; positionMs = 0; durationMs = 0; loadedPath = null
    }
}
