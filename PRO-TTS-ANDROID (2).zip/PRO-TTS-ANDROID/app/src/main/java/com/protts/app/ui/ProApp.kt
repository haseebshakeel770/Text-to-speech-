package com.protts.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.protts.app.MainViewModel
import com.protts.app.data.AudioItem

@Composable
fun ProApp(vm: MainViewModel) {
    val nav = rememberNavController()
    val ctx = LocalContext.current

    val mp3 = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mpeg")) { it?.let(vm::exportTo) }
    val m4a = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/mp4")) { it?.let(vm::exportTo) }
    val wav = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-wav")) { it?.let(vm::exportTo) }

    val export: (AudioItem) -> Unit = { a ->
        vm.pendingExport = a
        val fileName = a.name.replace(Regex("[^\\p{L}\\p{N}_ -]"), "_").trim().ifBlank { "audio" }
        when (a.format) {
            "mp3" -> mp3.launch("$fileName.mp3")
            "m4a" -> m4a.launch("$fileName.m4a")
            else -> wav.launch("$fileName.wav")
        }
    }
    val share: (AudioItem) -> Unit = { a -> ctx.startActivity(vm.shareIntent(a)) }
    val go: (String) -> Unit = { nav.navigate(it) }
    val back: () -> Unit = { nav.popBackStack() }

    NavHost(nav, startDestination = "splash") {
        composable("splash") {
            SplashScreen {
                nav.navigate(if (vm.onboardingDone) "home" else "onboarding") { popUpTo("splash") { inclusive = true } }
            }
        }
        composable("onboarding") {
            OnboardingScreen {
                vm.finishOnboarding()
                nav.navigate("home") { popUpTo("onboarding") { inclusive = true } }
            }
        }
        composable("home") { DashboardScreen(vm, go, export) }
        composable("editor") { EditorScreen(vm, back) }
        composable("languages") { LanguageScreen(vm, back) }
        composable("voices") { VoiceScreen(vm, back) }
        composable("player") { PlayerScreen(vm, back, export, share) }
        composable("library") { LibraryScreen(vm, go, back, export, share) }
        composable("history") { HistoryScreen(vm, back, go) }
        composable("settings") { SettingsScreen(vm, back, go) }
        composable("about") { AboutScreen(back) }
        composable("help") { HelpScreen(back) }
    }
}
