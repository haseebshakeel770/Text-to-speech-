# PRO TTS (Android)

Native Android text-to-speech app: Kotlin, Jetpack Compose, MVVM, Coroutines, Room.
Zero paid services: speech comes from the TTS engine already installed on the phone
(Android `TextToSpeech`), so it works offline when offline voice data is installed.

## What is real / what is not
- Speech engine: Android system TTS (Google Speech Services, eSpeak NG, RHVoice, Samsung TTS...).
  Languages and voices shown in the app are exactly what the installed engine reports. Nothing is invented.
- Urdu: shown only if your installed engine supports it. No fake Urdu voice is claimed.
- Gender labels: Android has no reliable male/female flag, so voices are listed by name; use Preview.
- Speed / pitch are passed to the engine; volume is applied to the generated PCM. All affect the real file.
- Long text: split at sentence boundaries, synthesized part by part, joined into one audio file.
- Export: WAV (always), M4A/AAC via MediaCodec (always), MP3 via LAME (TAndroidLame from JitPack).
  If the LAME library cannot load, the app says so and saves M4A instead.
- Not included in v1.0: Piper/ONNX neural voices (planned as an optional download feature).

## Build the APK with GitHub Actions (free)
1. Create a GitHub repository and upload everything in this folder (keep `.github/workflows`).
2. Open the Actions tab -> "Android Build" (runs on push, or press "Run workflow").
3. When green, open the run and download artifact `PRO-TTS-debug-apk`.

## Build in Android Studio
Open this folder (Android Studio Koala or newer, JDK 17), let Gradle sync (Gradle 8.9), then Run or
Build > Build APK(s). Requires internet for first sync (Maven Central, Google, JitPack).

## Status
Written without access to a build machine: the project has NOT been compiled or run on a device yet.
First GitHub build may need small fixes; paste the error log and it can be corrected.
